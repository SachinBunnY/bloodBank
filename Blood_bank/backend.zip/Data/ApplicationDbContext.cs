// File: Data/ApplicationDbContext.cs

using Microsoft.EntityFrameworkCore;
using BloodBank.Backend.Models;

namespace BloodBank.Backend.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<User> Users { get; set; }
    }
}


